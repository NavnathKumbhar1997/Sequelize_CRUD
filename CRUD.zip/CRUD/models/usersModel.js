module.exports = (sequelize, Sequelize) => {
    const UserData = sequelize.define("UsersData", {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement:true,
        primaryKey: true
      },
      name: {
        type: Sequelize.STRING
      },
      age: {
        type: Sequelize.INTEGER
      },
      address: {
        type: Sequelize.STRING
      }
    });
  
    return UserData;
  };